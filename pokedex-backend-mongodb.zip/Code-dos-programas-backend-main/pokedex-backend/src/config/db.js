const { MongoClient } = require('mongodb');
const config = require('./index');

let client;
let db;

/**
 * Conecta ao MongoDB Atlas (uma única vez) e guarda a referência do banco
 * em memória para ser reutilizada pelos services.
 */
async function connectDB() {
  if (db) return db;

  client = new MongoClient(config.mongoUri);
  await client.connect();
  db = client.db(config.mongoDbName);

  console.log(`🗄️  Conectado ao MongoDB Atlas (banco: ${config.mongoDbName})`);
  return db;
}

/**
 * Retorna a instância do banco já conectada. Lança erro se chamada antes
 * de connectDB() ter sido executado (o que acontece no boot do server).
 */
function getDB() {
  if (!db) {
    throw new Error('Banco de dados ainda não foi conectado. Chame connectDB() primeiro.');
  }
  return db;
}

module.exports = { connectDB, getDB };
