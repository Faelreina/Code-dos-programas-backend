const app = require('./app');
const config = require('./config');
const { connectDB } = require('./config/db');

async function start() {
  try {
    await connectDB();

    app.listen(config.port, () => {
      console.log(`🚀 PokéDex API rodando em http://localhost:${config.port}`);
      console.log(`   Consultando a PokéAPI em: ${config.pokeApiBaseUrl}`);
    });
  } catch (error) {
    console.error('❌ Erro ao conectar no MongoDB:', error.message);
    process.exit(1);
  }
}

start();
