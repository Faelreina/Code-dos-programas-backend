const { getDB } = require('../config/db');
const { NotFoundError, BadRequestError } = require('../utils/errors');

const COLLECTION_NAME = 'favorites';

function collection() {
  return getDB().collection(COLLECTION_NAME);
}

/** Remove o campo interno _id do Mongo antes de devolver pro cliente. */
function toPublic(doc) {
  if (!doc) return doc;
  const { _id, ...rest } = doc;
  return rest;
}

async function getAll() {
  const docs = await collection().find({}).sort({ favoritedAt: -1 }).toArray();
  return docs.map(toPublic);
}

/**
 * Adiciona um Pokémon aos favoritos.
 * @param {{id: number, name: string, image?: string}} pokemon
 */
async function add(pokemon) {
  if (!pokemon || pokemon.id === undefined || !pokemon.name) {
    throw new BadRequestError('Informe ao menos "id" e "name" do Pokémon a favoritar.');
  }

  const col = collection();
  const existing = await col.findOne({ id: Number(pokemon.id) });
  if (existing) {
    return toPublic(existing);
  }

  const favorite = {
    id: Number(pokemon.id),
    name: pokemon.name,
    image: pokemon.image || null,
    favoritedAt: new Date().toISOString(),
  };

  await col.insertOne(favorite);
  return favorite;
}

/**
 * Remove um favorito pelo id do Pokémon.
 */
async function remove(id) {
  const col = collection();
  const doc = await col.findOne({ id: Number(id) });
  if (!doc) {
    throw new NotFoundError(`Pokémon com id ${id} não está na lista de favoritos.`);
  }
  await col.deleteOne({ id: Number(id) });
  return toPublic(doc);
}

module.exports = { getAll, add, remove };
